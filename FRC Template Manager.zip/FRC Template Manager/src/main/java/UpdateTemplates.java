import com.intellij.ide.fileTemplates.FileTemplate;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.ui.Messages;
import com.sun.tools.internal.ws.wsdl.document.Import;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.io.jsonRpc.MessageServer;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import javax.swing.plaf.IconUIResource;
import java.io.*;
import java.util.Objects;

public class UpdateTemplates extends AnAction {

    @Override
    public void actionPerformed(@NotNull AnActionEvent e) {

        ImportantResources.downloadRemoteRepository();
        String description = "Please choose the '.IntelliJIdea' folder. It can be found in Windows under C:\\Users\\{USER}";

        String stringPath = ImportantResources.getPathFolderChooser("Tecbot FRC Template Manager", description);

        //Messages.showWarningDialog(stringPath,"Tecbot");
        if(stringPath==null || !stringPath.contains("IntelliJ")){
            Messages.showErrorDialog("Path not found.","Tecbot FRC Template Manager");
            return;
        }
        Messages.showInfoMessage("Copying File Templates to " + stringPath, "FRC Template Manager");
        File targetPath = new File(stringPath+"\\config\\fileTemplates");
        File sourceFolder = new File("C:\\TecbotFRC_Templates\\fileTemplates");
        try {
            ImportantResources.copyFolder(sourceFolder,targetPath);
            Messages.showInfoMessage("Files successfully copied. Please restart IntelliJIdea","Tecbot FRC Template Manager");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        //TIENE EL '/' NORMAL O SEA ESE
        //Messages.showInfoMessage(System.getProperty("os.name"),"fjaf");
    }
}
