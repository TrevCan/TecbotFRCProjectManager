import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vfs.VirtualFile;

import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class ImportantResources {

    public static String getPathFolderChooser(String title, String description){

        FileChooserDescriptor fileChooserDescriptor = new FileChooserDescriptor(false, true, false, false, false, false);
        fileChooserDescriptor.setTitle(title);
        fileChooserDescriptor.setDescription(description);


        //FileChooser.chooseFile(fileChooserDescriptor, null, virtualFile, null);
        //fileChooserDescriptor.

        VirtualFile files = FileChooser.chooseFile(fileChooserDescriptor, (Component) null, null, null);
        if(files!=null){
            //Messages.showMessageDialog((Project) null,files.getPath(), "PATH", Messages.getInformationIcon());
            return files.getPath();
        }
        return null;

    }


    public static void copyFolder(File sourceFolder, File destinationFolder) throws IOException {
        //Check if sourceFolder is a directory or file
        //If sourceFolder is file; then copy the file directly to new location
        if (sourceFolder.isDirectory()) {
            //Verify if destinationFolder is already present; If not then create it
            if (!destinationFolder.exists()) {
                destinationFolder.mkdir();
                System.out.println("Directory created :: " + destinationFolder);
            }

            //Get all files from source directory
            String files[] = sourceFolder.list();

            //Iterate over all files and copy them to destinationFolder one by one
            for (String file : files) {
                File srcFile = new File(sourceFolder, file);
                File destFile = new File(destinationFolder, file);

                //Recursive function call
                copyFolder(srcFile, destFile);
            }
        } else {
            //Copy the file content from one place to another
            Files.copy(sourceFolder.toPath(), destinationFolder.toPath(), StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File copied :: " + destinationFolder);
        }
    }

    public static void downloadRemoteRepository(){

        //DOWNLOAD REMOTE REPOSITORY
        Messages.showInfoMessage("Downloading repositories...", "Tecbot");
        //FileTemplate f;
        ProcessBuilder builder = new ProcessBuilder(
                "cmd.exe", "/c", "cd C:/ && git clone https://github.com/Tecbot3158/TecbotFRC_Templates");
        builder.redirectErrorStream(true);
        Process p = null;
        try {
            p = builder.start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while (true) {
            line = null;
            try {
                line = r.readLine();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            if (line == null) {
                break;
            }
            System.out.println(line);
        }

        System.out.println("apparently works!");
        Messages.showInfoMessage("Repository has been successfully downloaded!", "FRC Templates Manager");

        //DOWNLOAD REMOTE REPOSITORY ENDS
    }


}
